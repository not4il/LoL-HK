<?php

  header("Location: ../login");
  die();

?>
