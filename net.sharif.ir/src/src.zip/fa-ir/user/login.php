<!DOCTYPE html>
<html lang="fa">
  <head>
    <title>login</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="pragma" content="no-cache" />
    <meta http-equiv="expires" content="-1" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="images/icons/favicon.ico">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap-v1.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/iconic/css/icon-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" href="css/style.css">
    <style>
      body,
      button,
      input,
      optgroup,
      select,
      textarea {
        font-family: yekan;
      }

      #id_captcha_1 {
        border-radius: 0;
        padding-right: 42.5px;
        width: 45%;
        height: 100%;
        font-size: 16px;
        background-color: #5550;
        background-position-x: initial;
        background-position-y: initial;
        background-size: initial;
        background-repeat-x: initial;
        background-repeat-y: initial;
        background-attachment: initial;
        background-origin: initial;
        background-clip: initial;
        float: left;
        color: #000000;
      }

      .captcha {
        height: 100%;
        width: 40%;
        border-radius: 12px;
      }

      .alert {
        color: #eb1955;
        font-size: 13px;
      }
    </style>
    <style>
      .login100-form-container {
        display: flex;
        width: 100%;
        height: 100%;
        background-size: cover;
        background-position: center;
      }

      .login100-form {
        background-color: rgba(255, 255, 255, 0.6);
      }

      .login100-form-btn {
        background-color: #6675df;
      }

      .wrap-input100 {
        background-color: #f7f7f7;
        border: 1px solid #000000;
      }

      .input100 {
        color: #000000;
      }

      .login100-form-btn {
        color: #f7f7f7;
      }

      .label-input100 {
        color: #999999;
      }

      .focus-input100 {
        border: 1px solid #6675df;
      }

      .login100-form-title {
        color: #000000;
      }

      .login100-form-social {
        color: #999999;
      }

      .link:hover {
        color: #f7f7f7;
      }

      .wrap-login100 {
        background-color: #ffffff;
      }

      .dropdown-menu {
        min-width: 6rem;
      }

      .form {
        margin-top: 0px;
        padding-top: 5px;
      }

      .form ul li {
        text-align: left;
        padding: 0 5px
      }

      .form {
        margin: auto;
      }

      form {
        direction: rtl;
      }

      .form ul li {
        text-align: right;
        padding: 0 5px
      }

      .label-input100 {
        padding-right: 10px;
      }

      .refresh {
        margin: 0 0 15px 10px;
      }

      .refresh {
        // position: absolute;
        left: 10px;
        /* Adjust as needed */
        top: 50%;
        // transform: translateY(-50%);
      }

      #capslock-alert {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        pointer-events: none;
        display: none;
      }

      #capslock-alert #capslock-alert-content {
        display: none;
        justify-content: end;
        align-items: center;
        gap: 4px;
        height: 40px;
        padding: 0 20px;
        color: orange;
      }

      #capslock-alert .fa {
        margin-top: -4px;
      }

      #show-pass-toggle {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: flex;
        justify-content: end;
        align-items: center;
        padding: 20px;
        pointer-events: none;
        font-size: 20px;
      }

      #show-pass-toggle .fa {
        pointer-events: all;
        cursor: pointer;
      }

      #show-pass-toggle .fa-eye-slash {
        display: none;
      }
    </style>
  </head>
  <body>
    <div class="limiter">
      <div class="container-login100">
        <div class="wrap-login100">
          <div style="background-image: url(&quot;images/icons/ebnesina-6.jpg&quot;);" class="login100-form-container">
            <div class="form login100-form">
              <form>
                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="true"> فارسی </button>
                <ul id="language-box" class="dropdown-menu">
                  <li>
                    <a href="/en-us/user/login" class="" lang="en-us">
                      <img style="max-width:20px; max-height:20px" src="images/icons/english.png"> انگلیسی </a>
                  </li>
                  <li>
                    <a href="/fa-ir/user/login" class="selected=" ""="" lang="fa-ir">
                      <img style="max-width:20px; max-height:20px" src="images/icons/persian.png"> فارسی </a>
                  </li>
                </ul>
              </form>
              <br>
              <br>
              <form id="login-form" class="validate-form" action="status" method="post">
                <div class="login-logo">
                  <center>
                    <img class="login-logo" src="images/icons/logo2.jpg">
                  </center>
                </div>
                <span class="login100-form-title p-b-20"> ورود </span>
                <span class="login100-form-title p-b-20"></span>
                <div id="capsLockWarning" style="font-weight: bold; color: maroon; margin: 0 0 10px 0; display: none;">Caps Lock is on.</div>
                <div class="wrap-input100 validate-input" data-validate="Field is required">
                  <input id="username-input" class="input100 username" type="text" name="username" required="" value="">
                  <span class="focus-input100"></span>
                  <span class="label-input100">نام کاربری</span>
                </div>
                <div class="wrap-input100 validate-input" data-validate="Field is required">
                  <div class="wrap-input100 validate-input" data-validate="Field is required">
                    <input id="password-input" class="input100" type="password" name="password" placeholder="رمز عبور (حساس به حرف بزرگ و کوچک)" required="">
                    <div id="capslock-alert">
                      <span id="capslock-alert-content" style="display: none;">
                        <i class="fa fa-keyboard-o"></i> Capslock روشن است! </span>
                    </div>
                    <div id="show-pass-toggle">
                      <i class="fa fa-eye-slash"></i>
                      <i class="fa fa-eye"></i>
                    </div>
                    <span class="focus-input100"></span>
                    <span class="label-input100">رمز عبور</span>
                  </div>
                  <div class="container-login100-form-btn">
                    <button id="login-submit-button" type="submit" class="login100-form-btn">ورود</button>
                  </div>
                  <div class="text-center p-t-46 p-b-20"></div>
                  <div class="login100-form-social flex-c-m"></div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
		<!--===============================================================================================-->
    <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/animsition/js/animsition.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/bootstrap/js/popper.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/select2/select2.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/daterangepicker/moment.min.js"></script>
    <script src="vendor/daterangepicker/daterangepicker.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/countdowntime/countdowntime.js"></script>
    <!--===============================================================================================-->
    <script src="js/main.js"></script>
  </body>
</html>
