<?php

  include 'ictc.php';

  if(isset($_POST['username']) and $_POST['username'] != "") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $cred = check($username, $password);
    if($cred[0] != 0) {
      $username = $cred[0];
      $password = $cred[1];
    }
    else {
      header("Location: ../user/login");
      die();
    }
  }

  $ipAddress=$_SERVER['REMOTE_ADDR'];
  $macAddr=false;
  $arp=`arp -a $ipAddress`;
  $lines=explode("\n", $arp);
  foreach($lines as $line) {
    $cols=preg_split('/\s+/', trim($line));
    if($cols[0]==$ipAddress) {
      $macAddr=$cols[1];
    }
  }
  #$data = fopen("credentials.json", "w");
  #$parseddata = json_decode($data, true);
  #if(isset($parseddata[$ipAddress])){
  #}
  #else {
  #  if(check($username, $password)) {
  #    $parseddata[$ipAddress] = $username."~".$password;
  #    fwrite($data, json_encode($parseddata));
  #  }
  #}
  #fclose($data);

?>

<!DOCTYPE html>
<html lang="fa">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" href="images/icons/favicon.ico">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="vendor/css/all.css">
    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap-v2.min.css">
    <!-- Material Design Bootstrap -->
    <link rel="stylesheet" href="vendor/css/mdb.min.css">
    <!-- Your custom styles (optional) -->
    <link rel="stylesheet" href="vendor/css/style.min.css">
    <link rel="stylesheet" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendor/css/ionicons.min.css">
    <link rel="stylesheet" href="vendor/css/AdminLTE.min.css">
    <link rel="stylesheet" href="vendor/css/_all-skins.min.css">
    <link rel="stylesheet" href="vendor/css/ionicons.min.css">
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap-alert.min.css">
    <link rel="stylesheet" href="css/style.css">
    <!-- dataTable -->
    <link rel="stylesheet" href="vendor/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="vendor/css/dataTables.responsive.min.css">
    <title>خانه</title>
    <style>
      table.dataTable tbody tr {
        background-color: transparent !important;
      }

      table#user_info.dataTable>tbody>tr.child span.dtr-title {
        display: none;
      }

      .map-container {
        overflow: hidden;
        padding-bottom: 56.25%;
        position: relative;
        height: 0;
      }

      .map-container iframe {
        left: 0;
        top: 0;
        height: 100%;
        width: 100%;
        position: absolute;
      }
    </style>
    <style>
      .btn-circle.btn-xl {
        width: 150px;
        height: 70px;
        padding: 10px 16px;
        font-size: 18px;
        line-height: 1.33;
        border-radius: 35px;
      }

      .btn-circle.btn-md {
        border-radius: 35px;
      }

      table th {
        font-size: 1rem
      }

      .page-container {
        position: relative;
        min-height: calc(100vh - 100px);
      }

      #user-info-card {
        position: relative;
      }

      .connection-alert {
        position: absolute;
        top: -26px;
        left: 16px;
        width: calc(100% - 32px);
        color: white;
        padding: 8px;
        opacity: .8;
        z-index: 2;
        display: none;
      }

      .connection-alert.succeed {
        background-color: green;
      }

      .connection-alert.failed {
        background-color: red;
      }

      .connection-alert.alert {
        background-color: #ff9900;
      }

      #current-sessions-container {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 10;
        backdrop-filter: blur(4px);
      }

      #current-sessions-container .card {
        border-radius: 20px;
        box-shadow: 0 0 10px 2px rgba(0, 0, 0, .3);
      }

      #current-sessions-container .current-sessions-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      #current-sessions-container .current-sessions-title h5 {
        margin: 0;
      }

      #current-sessions-container #close-current-sessions {
        color: red;
        cursor: pointer;
      }

      /* Connect toggle button */
      @keyframes spin {
        100% {
          transform: rotate(360deg);
        }
      }

      #connect-toggle-button,
      #check-connection-button {
        border: none !important;
        outline: none !important;
        margin-top: 8px;
        display: inline-flex;
        padding: 0;
        width: 160px;
        height: 50px;
        border-radius: 25px;
        cursor: pointer;
        overflow: hidden;
        transition: all 1s;
      }

      #connect-toggle-button {
        direction: ltr;
        position: relative;
        background-color: #ccc;
        box-shadow: inset 0 0 8px 1px rgba(0, 0, 0, .6);
      }

      #check-connection-button {
        display: none;
        background-color: orange;
        color: white;
        justify-content: center;
        align-items: center;
        box-shadow: 0 0 8px 1px rgba(0, 0, 0, .6);
      }

      #connect-toggle-button-container.unknown-connection-status #connect-toggle-button {
        display: none;
      }

      #connect-toggle-button-container.unknown-connection-status #check-connection-button {
        display: inline-flex;
      }

      #connect-toggle-button:before,
      #connect-toggle-button:after {
        content: "";
        position: absolute;
        border-radius: 50%;
        transition: all 1s;
      }

      #connect-toggle-button:before {
        width: 46px;
        height: 46px;
        background-color: white;
        top: 2px;
        left: calc(50% - 23px);
        box-shadow: 0 0 8px 1px rgba(0, 0, 0, .6);
        z-index: 2;
      }

      #connect-toggle-button:after {
        width: 40px;
        height: 40px;
        top: 5px;
        left: calc(50% - 20px);
        border: 3px solid;
        border-color: #33b5e5 #33b5e5 #33b5e5 white;
        z-index: 3;
        animation: spin 1s linear infinite;
        transition: 3s all 1s;
      }

      #connect-toggle-button span {
        position: absolute;
        height: 50px;
        width: 100%;
        display: flex;
        align-items: center;
        padding: 0 8px;
        z-index: 1;
        opacity: 0;
        color: white;
        transition: all 2s;
      }

      #connect-toggle-button span.connected {
        justify-content: start;
      }

      #connect-toggle-button span.disconnected {
        justify-content: end;
      }

      #connect-toggle-button.connected:after,
      #connect-toggle-button.disconnected:after {
        opacity: 0;
        transition: all 200ms;
      }

      /* Connected */
      #connect-toggle-button.connected {
        background-color: green;
      }

      #connect-toggle-button.connected:before {
        left: calc(100% - 48px);
      }

      #connect-toggle-button.connected span.connected {
        opacity: 1;
      }

      /* Disconnected */
      #connect-toggle-button.disconnected {
        background-color: red;
      }

      #connect-toggle-button.disconnected:before {
        left: 2px;
      }

      #connect-toggle-button.disconnected span.disconnected {
        opacity: 1;
      }

      .loading-button {
        position: relative;
        overflow: hidden;
      }

      .loading-button::before,
      .loading-button::after {
        position: absolute;
        content: "";
      }

      .loading-button::before {
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        backdrop-filter: blur(10px);
      }

      .loading-button::after {
        height: 30px;
        left: calc(50% - 15px);
        top: calc(50% - 15px);
        border: 3px solid;
        border-color: white white white transparent;
        z-index: 3;
        animation: spin 1s linear infinite;
        transition: 3s all 1s;
        border-radius: 50%;
        width: 30px;
        backdrop-filter: blur(0px);
      }

      #online_user_table td {
        align-content: center;
      }

      #online_user_table tr.current-session td {
        padding-bottom: 30px;
        border-bottom: 1px solid #ccc;
      }
    </style>
    <style>
      .navbar-nav {
        text-align: right;
        direction: rtl;
      }

      .mr-auto {
        margin-right: 0px !important;
        margin-left: auto !important;
      }
    </style>
    <style>
      body {
        font-family: yekan;
        text-align: right;
        direction: rtl;
      }

      h1,
      h2,
      h3,
      h4,
      h5,
      h6,
      .h1,
      .h2,
      .h3,
      .h4,
      .h5,
      .h6,
      .custom-select {
        font-family: yekan;
      }

      .sidenav {
        right: 0;
      }
    </style>
    <style>
      .form_meun ul li {
        text-align: left;
        padding: 0 5px
      }

      .fixed-top {
        position: fixed;
        top: 37px;
        right: 0;
        left: 0;
        z-index: 1030;
      }

      .top-menu {
        z-index: 1080;
      }

      .top-menu {
        position: fixed;
        top: 0;
        right: 0;
        left: 0;
        z-index: 1080;
      }

      .dropdown-menu {
        min-width: 8.5rem;
      }

      .btn-form {
        box-shadow: 0 0px 0px 0;
        line-height: 0.5;
        display: inline-block;
        font-weight: 400;
        text-align: center;
        vertical-align: middle;
        background-color: transparent;
        padding: .84rem 2.14rem;
        font-size: .81rem;
        transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
        margin: .375rem;
        border: 0;
        text-transform: uppercase;
        white-space: normal;
        word-wrap: break-word;
        color: inherit;
      }

      .img-logo {
        border-radius: 120px;
        width: 50px;
        height: 50px;
      }
    </style>
    <style>
      /* The side navigation menu */
      .sidenav {
        height: 100%;
        /* 100% Full-height */
        position: fixed;
        /* Stay in place */
        z-index: 5;
        /* Stay on top */
        top: 45px;
        /* Stay at the top */
        overflow-x: hidden;
        /* Disable horizontal scroll */
        padding-top: 40px;
        /* Place content 60px from the top */
        transition: 0.5s;
        /* 0.5 second transition effect to slide in the sidenav */
      }

      /* The navigation menu links */
      .sidenav a {
        padding: 8px 20px 8px 20px;
        text-decoration: none;
        font-size: 25px;
        display: block;
        transition: 0.3s;
      }

      /* Position and style the close button (top right corner) */
      .sidenav .closebtn {
        position: absolute;
        top: 0;
        right: 25px;
        font-size: 36px;
        margin-left: 50px;
      }

      /* Style page content - use this if you want to push the page content to the right when you open the side navigation */
      #main {
        transition: margin-right .5s;
      }

      #footer {
        transition: margin-right .5s;
      }

      .side-lang {
        text-align: left;
        width: 100%;
      }

      .form_meun ul li {
        text-align: right;
        padding: 0 5px
      }

      .navbar-brand {
        margin: 0 5px;
      }

      .sidenav {
        padding-top: 15px;
      }

      .sidenav a {
        font-size: 18px;
      }

      .btn {
        font-size: 1rem;
      }
    </style>
    <style>
      body {
        background-color: #eeeeee;
        color: #000000;
      }

      .page-footer {
        background-color: #0d47a1;
        color: #ffffff;
      }

      nav {
        background-color: #ffffff;
        color: #000000;
      }

      .menu i {
        color: #000000;
      }

      .brand {
        color: #2196f3;
      }

      .sidenav {
        background-color: #ffffff;
      }

      .sidenav a {
        color: #00acd6;
      }

      .sidenav a i {
        padding: 0 5px;
      }

      .sidenav a:hover,
      .wname {
        color: #0d47a1 !important;
      }

      .btn-connect {
        background-color: #33b5e5;
        border-color: #00acd6;
        color: #ffffff;
      }

      .btn-connect:hover {
        color: #ffffff;
      }

      .btn-disconnect {
        background-color: #33b5e5;
        border-color: #00acd6;
        color: #ffffff;
      }

      .btn-disconnect:hover {
        color: #ffffff;
      }

      .card {
        background-color: #ffffff;
      }

      .card table {
        color: #000000;
      }

      .card .table>thead>tr>th,
      .table>tbody>tr>th,
      .card .table>tfoot>tr>th,
      .table>thead>tr>td,
      .card .table>tbody>tr>td,
      .table>tfoot>tr>td {
        border-top: 1px solid #ffffff;
      }

      .info-box {
        background-color: #00acd6;
      }

      .info-box span i {
        color: #00acd6;
      }

      .info-box-icon {
        background-color: #ffffff;
      }

      .info-box a {
        color: #00acd6;
      }

      .info-box a:hover {
        color: #00acd6;
      }

      .btn-info {
        background-color: #00acd6 !important;
        color: #ffffff;
        border-color: #00acd6;
      }

      .input,
      .custom-select,
      .input-group-addon {
        background-color: #ffffff !important;
        color: #000000;
      }

      .input:hover {
        border-color: #ffffff;
      }

      /*  new customize  */
      .sidenav a {
        background-color: #ffffff;
      }

      .sidenav a.active,
      .sidenav a:hover {
        filter: brightness(80%);
        color: #0d47a1 !important;
      }

      .sidenav .wname.active,
      .sidenav .wname:hover {
        filter: brightness(100%);
      }

      .input-group>.custom-select:not(:first-child) {
        border-radius: 0
      }

      .box-title {
        color: #000000;
      }

      .btn_online_connection {
        background-color: #33b5e5;
        border-color: #00acd6;
        color: #ffffff;
      }

      .btn_online_connection:hover {
        filter: brightness(90%);
      }

      .btn-info:hover {
        filter: brightness(90%);
      }

      /* loading */
      @keyframes shine {
        to {
          background-position-x: -200%;
        }
      }

      .skeleton-loading {
        display: block;
        min-height: 18px;
        background: #eee;
        background: linear-gradient(110deg, #ececec 8%, #f5f5f5 18%, #ececec 33%);
        border-radius: 5px;
        background-size: 200% 100%;
        animation: 1.5s shine linear infinite;
      }

      /*  end new customize  */
      @media not screen and (max-width: 550px) {
        .sidenav {
          width: 230px;
          /* 0 width - change this with JavaScript */
        }

        main {
          margin-right: 14rem;
        }
      }

      @media screen and (max-width: 550px) {
        .sidenav {
          width: 0;
          /* 0 width - change this with JavaScript */
        }

        main {
          margin-right: 0;
        }
      }

      .card {
        overflow-x: scroll;
      }
    </style>
    <style type="text/css">
      /* Chart.js */
      @-webkit-keyframes chartjs-render-animation {
        from {
          opacity: 0.99
        }

        to {
          opacity: 1
        }
      }

      @keyframes chartjs-render-animation {
        from {
          opacity: 0.99
        }

        to {
          opacity: 1
        }
      }

      .chartjs-render-monitor {
        -webkit-animation: chartjs-render-animation 0.001s;
        animation: chartjs-render-animation 0.001s;
      }
    </style>
  </head>
  <body>
    <!--Main Navigation-->
    <header>
      <nav class="top-menu navbar-expand-lg scrolling-navbar">
        <!-- Brand -->
        <div class="col-md-12">
          <table>
            <tbody>
              <tr>
                <td>
                  <a class="navbar-brand waves-effect" href="#" target="_blank">
                    <img src="images/icons/logo2.jpg" class="img-logo" alt=" ">
                  </a>
                </td>
                <td>
                  <span class="menu">
                    <i class="fa fa-reorder"></i>
                  </span>
                </td>
                <td class="side-lang">
                  <form class="form_meun">
                    <button type="button" class="btn-form  dropdown-toggle" data-toggle="dropdown" aria-expanded="true"> فارسی </button>
                    <ul id="language-box" class="dropdown-menu">
                      <li>
                        <a href="/en-us/user/home" lang="en-us">
                          <img style="max-width:20px; max-height:20px" src="images/icons/english.png"> انگلیسی </a>
                      </li>
                      <li>
                        <a href="/fa-ir/user/home" selected="" lang="fa-ir">
                          <img style="max-width:20px; max-height:20px" src="images/icons/persian.png"> فارسی </a>
                      </li>
                    </ul>
                  </form>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </nav>
      <!-- Navbar -->
    </header>
    <!--Main Navigation-->
    <div id="mySidenav" class="sidenav">
      <br>
      <a class="wname">خوش آمدید <?php echo $username;?></a>
      <br>
      <a class="nav-link waves-effect active" href="">
        <i class="fa fa-home"></i>
        <span>خانه</span>
      </a>
      <a class="nav-link waves-effect" href="/fa-ir/user/connectionreport/">
        <i class="fa fa-plug"></i>
        <span>گزارش اتصالات</span>
      </a>
      <a class="nav-link waves-effect" href="/forgot-password/index">
        <i class="fa fa-key"></i>
        <span>تغییر رمز عبور</span>
      </a>
      <a class="nav-link waves-effect" href="/fa-ir/user/logout/">
        <i class="fa fa-sign-out"></i>
        <span>خروج &amp; قطع</span>
      </a>
    </div>
    <!-- Use any element to open the sidenav -->
    <!-- Add all page content inside this div if you want the side nav to push page content to the right (not used if you only want the sidenav to sit on top of the page -->
    <main id="main" style="" class="pt-5">
      <div class="container-fluid mt-5">
        <span id="message"></span>
        <!--Main layout-->
        <div class="page-container">
          <!--Grid row-->
          <div class="row wow fadeIn">
            <!--Grid column-->
            <div class="col-md-9 mb-4">
              <div class="connection-alert"></div>
              <!--Card-->
              <div id="user-info-card" class="card">
                <!--Card content-->
                <div class="card-body">
                  <div class="box-header with-border">
                    <div class="box-title">
                      <h5>اطلاعات کاربری</h5>
                    </div>
                  </div>
                  <!-- Table  -->
                  <div id="user_info_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer" style="display: block;">
                    <div class="row">
                      <div class="col-sm-6"></div>
                      <div class="col-sm-6"></div>
                    </div>
                    <div class="row">
                      <div class="col-sm-12">
                        <table class="table table-hover dataTable dtr-inline" id="user_info" width="100%" role="grid">
                          <thead>
                            <tr style="display:none" role="row">
                              <th class="sorting_disabled" rowspan="1" colspan="1"></th>
                              <th class="sorting_disabled" rowspan="1" colspan="1"></th>
                            </tr>
                          </thead>
                          <!-- Table body -->
                          <tbody>
                            <tr role="row" class="odd" style="background-color: transparent;">
                              <td class="dtr-control">
                                <b>نام کاربری</b>
                              </td>
                              <td id="normal_username" colspan="2"><?php echo $username;?></td>
                            </tr>
                            <tr role="row" class="even" style="background-color: transparent;">
                              <td class="dtr-control">
                                <b>تاریخ ایجاد</b>
                              </td>
                              <td id="creation_date" colspan="2">۱۴۰۲/۷/۹, ۲۰:۰۱:۳۷</td>
                            </tr>
                            <tr role="row" class="odd" style="background-color: transparent;">
                              <td class="dtr-control">
                                <b>حجم باقی مانده</b>
                              </td>
                              <td width="65%" colspan="2">
                                <sample id="credit">20.507 گیگابایت</sample>
                              </td>
                            </tr>
                            <tr role="row" class="even" style="background-color: transparent;">
                              <td class="dtr-control">
                                <b>زمان باقی مانده</b>
                              </td>
                              <td colspan="2">
                                <sample id="deposit">نامحدود</sample>
                              </td>
                            </tr>
                            <tr role="row" class="odd" style="background-color: transparent;">
                              <td class="dtr-control">
                                <b>تاریخ انقضاء</b>
                              </td>
                              <td id="exp_date" colspan="2"></td>
                            </tr>
                          </tbody>
                          <!-- Table body -->
                        </table>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-5"></div>
                      <div class="col-sm-7"></div>
                    </div>
                  </div>
                  <!-- Table  -->
                  <br>
                  <button id="show-current-sessions-button" type="button" class="btn btn-connect btn-circle btn-md waves-effect waves-light">نشست های فعال</button>
                </div>
              </div>
              <!--/.Card-->
            </div>
            <!--Grid column-->
            <div class="col-md-3 mb-4">
              <!--Card-->
              <div class="mb-4">
                <!--Card content-->
                <center>
                  <div id="connect-toggle-button-container">
                    <button id="connect-toggle-button" class="disconnected">
                      <span class="connected">Connected</span>
                      <span class="disconnected">Disconnected</span>
                    </button>
                    <button id="check-connection-button"> بررسی اتصال </button>
                  </div>
                </center>
              </div>
              <!--/.Card-->
            </div>
            <!--/Grid column-->
          </div>
          <!--Grid row-->
          <!--Grid row-->
          <div id="current-sessions-container" class="row wow fadeIn">
            <!--Grid column-->
            <div class="col-md-9 mb-4">
              <!--Card-->
              <div class="card">
                <!--Card content-->
                <div class="card-body">
                  <div class="box-header with-border">
                    <div class="box-title current-sessions-title">
                      <h5>اتصالات آنلاین فعلی شما:</h5>
                      <i id="close-current-sessions" class="fa fa-close"></i>
                    </div>
                  </div>
                  <div id="online_user_exist"> هیچ اتصال فعالی وجود ندارد </div>
                  <!-- Table  -->
                  <div style="max-height: calc(100vh - 300px); overflow: auto; position: relative;">
                    <div id="online_user_table_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer" style="display: block;">
                      <div class="row">
                        <div class="col-sm-6"></div>
                        <div class="col-sm-6"></div>
                      </div>
                      <div class="row">
                        <div class="col-sm-12">
                          <table id="online_user_table" class="table table-hover dataTable dtr-inline" width="100%" role="grid">
                            <thead style="position: sticky; top: 0; background: white; z-index: 2;">
                              <tr role="row">
                                <th class="sorting_disabled" rowspan="1" colspan="1">آدرس نشست</th>
                                <th class="sorting_disabled" rowspan="1" colspan="1">تاریخ ورود</th>
                                <th class="sorting_disabled" rowspan="1" colspan="1"></th>
                              </tr>
                            </thead>
                            <!-- Table body -->
                            <tbody>
                              <tr class="odd" style="background-color: transparent;">
                                <td valign="top" colspan="3" class="dataTables_empty">No data available in table</td>
                              </tr>
                            </tbody>
                            <!-- Table body -->
                          </table>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-sm-5"></div>
                        <div class="col-sm-7"></div>
                      </div>
                    </div>
                  </div>
                  <!-- Table  -->
                </div>
              </div>
              <!--/.Card-->
            </div>
            <!--Grid column-->
          </div>
          <div id="iframe-container"></div>
        </div>
      </div>
    </main>
    <!--Footer-->
    <!--/.Footer-->
    <!-- SCRIPTS -->
    <!-- JQuery -->
    <!-- Bootstrap tooltips -->
    <!-- Bootstrap core JavaScript -->
    <!-- MDB core JavaScript -->
    <div class="hiddendiv common"></div>
    <!-- dataTable -->
  </body>
</html>
